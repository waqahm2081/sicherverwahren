(function ($) {
    "use strict";
	
	var $window = $(window); 
	var $body = $('body'); 

	/* Preloader Effect — hide ASAP (do not wait for all assets) */
	function hidePreloader() {
		var $p = $(".preloader");
		if (!$p.length || $p.data('hidden')) return;
		$p.data('hidden', true).fadeOut(300);
	}
	$(function () { hidePreloader(); });
	$window.on('load', hidePreloader);
	setTimeout(hidePreloader, 1200);

	/* Sticky Header */	
	if($('.active-sticky-header').length){
		$window.on('resize', function(){
			setHeaderHeight();
		});

		function setHeaderHeight(){
	 		$("header.main-header").css("height", $('header .header-sticky').outerHeight());
		}	
	
		$window.on("scroll", function() {
			var fromTop = $(window).scrollTop();
			setHeaderHeight();
			var headerHeight = $('header .header-sticky').outerHeight()
			$("header .header-sticky").toggleClass("hide", (fromTop > headerHeight + 100));
			$("header .header-sticky").toggleClass("active", (fromTop > 600));
		});
	}	
	
	/* Slick Menu JS */
	$('#menu').slicknav({
		label : '',
		prependTo : '.responsive-menu'
	});

	/* Inject login/dashboard links into mobile menu */
	var authMobile = $('#header-auth-mobile-template .header-auth-mobile');
	if (authMobile.length && $('.slicknav_menu .header-auth-mobile').length === 0) {
		$('.slicknav_menu').append(authMobile.clone());
	}

	if($("a[href='#top']").length){
		$(document).on("click", "a[href='#top']", function() {
			$("html, body").animate({ scrollTop: 0 }, "slow");
			return false;
		});
	}

	/* Hero / testimonial / page sliders — init after Swiper loads */
	window.initPageSwipers = function () {
		if (typeof Swiper === 'undefined') return;

		if (document.querySelector('.hero-slider-layout .swiper')) {
			new Swiper('.hero-slider-layout .swiper', {
				slidesPerView: 1,
				speed: 1000,
				spaceBetween: 0,
				loop: true,
				autoplay: { delay: 4000 },
				pagination: { el: '.hero-pagination', clickable: true },
			});
		}

		if ($('.testimonial-slider').length) {
			new Swiper('.testimonial-slider .swiper', {
				slidesPerView: 1,
				speed: 1000,
				spaceBetween: 30,
				loop: true,
				autoplay: { delay: 5000 },
				navigation: {
					nextEl: '.testimonial-button-next',
					prevEl: '.testimonial-button-prev',
				},
			});
		}

		if ($('.page-single-slider').length) {
			new Swiper('.page-single-slider .swiper', {
				slidesPerView: 1,
				speed: 1000,
				spaceBetween: 30,
				loop: true,
				autoplay: { delay: 5000 },
				pagination: { el: '.page-single-pagination', clickable: true },
			});
		}
	};

	/* Skill Bar */
	if ($('.skills-progress-bar').length && typeof $.fn.waypoint === 'function') {
		$('.skills-progress-bar').waypoint(function() {
			$('.skillbar').each(function() {
				$(this).find('.count-bar').animate({
				width:$(this).attr('data-percent')
				},2000);
			});
		},{
			offset: '50%'
		});
	}

	/* Youtube Background Video JS */
	if ($('#herovideo').length && typeof $.fn.YTPlayer === 'function') {
		var myPlayer = $("#herovideo").YTPlayer();
	}

	/* Init Counter */
	if ($('.counter').length && typeof $.fn.counterUp === 'function') {
		$('.counter').counterUp({ delay: 6, time: 3000 });
	}

	/* Image Reveal Animation */
	if ($('.reveal').length && typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);
        let revealContainers = document.querySelectorAll(".reveal");
        revealContainers.forEach((container) => {
            let image = container.querySelector("img");
            let tl = gsap.timeline({
                scrollTrigger: {
                    trigger: container,
                    toggleActions: "play none none none"
                }
            });
            tl.set(container, {
                autoAlpha: 1
            });
            tl.from(container, 1, {
                xPercent: -100,
                ease: Power2.out
            });
            tl.from(image, 1, {
                xPercent: 100,
                scale: 1,
                delay: -1,
                ease: Power2.out
            });
        });
    }

	/* Parallaxie js */
	/* var $parallaxie = $('.parallaxie');
	if($parallaxie.length && ($window.width() > 991))
	{
		if ($window.width() > 768) {
			$parallaxie.parallaxie({
				speed: 0.55,
				offset: 0,
			});
		}
	} */

	/* Zoom Gallery screenshot */
	if ($('.gallery-items').length && typeof $.fn.magnificPopup === 'function') {
		$('.gallery-items').magnificPopup({
			delegate: 'a',
			type: 'image',
			closeOnContentClick: false,
			closeBtnInside: false,
			mainClass: 'mfp-with-zoom',
			image: {
				verticalFit: true,
			},
			gallery: {
				enabled: true
			},
			zoom: {
				enabled: true,
				duration: 300,
				opener: function(element) {
				  return element.find('img');
				}
			}
		});
	}

	/* Contact form validation */
	var $contactform = $("#contactForm");
	if ($contactform.length && typeof $.fn.validator === 'function') {
		$contactform.validator({focus: false}).on("submit", function (event) {
			if (!event.isDefaultPrevented()) {
				event.preventDefault();
				submitForm();
			}
		});
	}

	function submitForm(){
		/* Ajax call to submit form */
		$.ajax({
			type: "POST",
			url: "form-process.php",
			data: $contactform.serialize(),
			success : function(text){
				if (text === "success"){
					formSuccess();
				} else {
					submitMSG(false,text);
				}
			}
		});
	}

	function formSuccess(){
		$contactform[0].reset();
		submitMSG(true, "Message Sent Successfully!")
	}

	function submitMSG(valid, msg){
		if(valid){
			var msgClasses = "h4 text-success";
		} else {
			var msgClasses = "h4 text-danger";
		}
		$("#msgSubmit").removeClass().addClass(msgClasses).text(msg);
	}
	/* Contact form validation end */

	/* Animated Wow Js */	
	// new WOW().init();

	/* Popup Video */
	if ($('.popup-video').length && typeof $.fn.magnificPopup === 'function') {
		$('.popup-video').magnificPopup({
			type: 'iframe',
			mainClass: 'mfp-fade',
			removalDelay: 160,
			preloader: false,
			fixedContentPos: true
		});
	}

	/* Service Item Active Start */
	var $our_services = $('.our-services');
	if ($our_services.length) {
		var $service_item = $our_services.find('.service-item');

		if ($service_item.length) {
			$service_item.on({
				mouseenter: function () {
					if (!$(this).hasClass('active')) {
						$service_item.removeClass('active'); 
						$(this).addClass('active'); 
					}
				},
				mouseleave: function () {
					// Optional: Add logic for mouse leave if needed
				}
			});
		}
	}
	/* Service Item Active End  */

	/* Project Item Active Start */
	var $projects_list = $('.projects-list');
	if ($projects_list.length) {
		var $project_item = $projects_list.find('.project-item');

		if ($project_item.length) {
			$project_item.on({
				mouseenter: function () {
					if (!$(this).hasClass('active')) {
						$project_item.removeClass('active'); 
						$(this).addClass('active'); 
					}
				},
				mouseleave: function () {
					// Optional: Add logic for mouse leave if needed
				}
			});
		}
	}
	/* Project Item Active End  */
	
})(jQuery);