<div class="adm-topbar">
    <div class="adm-topbar__breadcrumb">
        Admin
        <svg viewBox="0 0 24 24"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
        <span><?php echo e($title); ?></span>
    </div>
    <span class="adm-topbar__date"><?php echo e(now()->format('d. M Y')); ?></span>
</div><?php /**PATH D:\New\waqas\Creative Solutions\projects\sicherbitcoin\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>